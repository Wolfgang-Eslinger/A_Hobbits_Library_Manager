# Wolfgang Eslinger
# 10/1/2023
# The "A Hobbit's Library Manager" is a GUI application that allows users to search for books, view their borrowed books, 
# and manage book borrowing and returning in a digital library system.

# Importing necessary libraries
import tkinter as tk
from PIL import Image, ImageTk
from tkinter import ttk, simpledialog, messagebox, Listbox
import sqlite3

# List to store image references and avoid garbage collection
image_references = []

# ---- DATABASE FUNCTIONS ----

# Function to create the necessary database tables
def create_database():
    # Connect to the SQLite database
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    # Create 'books' table if it doesn't exist
    cursor.execute('''CREATE TABLE IF NOT EXISTS books
                     (title TEXT, author TEXT, genre TEXT, status TEXT)''')

    # Create 'borrowed_books' table if it doesn't exist
    cursor.execute('''CREATE TABLE IF NOT EXISTS borrowed_books
                     (user TEXT, title TEXT, due_date DATE)''')

    # Commit changes and close connection
    conn.commit()
    conn.close()

# Function to populate the database with sample books
def populate_database():
    # Sample book entries
    sample_books = [
        ("The Hobbit", "J.R.R. Tolkien", "Fantasy", "Available"),
        ("The Fellowship of the Ring", "J.R.R. Tolkien", "Fantasy", "Available"),
        ("The Two Towers", "J.R.R. Tolkien", "Fantasy", "Available"),
        ("The Return of the King", "J.R.R. Tolkien", "Fantasy", "Available")
    ]

    # Connect to the SQLite database
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    # Insert sample books into the 'books' table
    cursor.executemany('''INSERT INTO books (title, author, genre, status) VALUES (?, ?, ?, ?)''', sample_books)

    # Commit changes and close connection
    conn.commit()
    conn.close()

# Function to search books based on user input
def search_books():
    # Get user's search term
    search_term = search_entry.get()

    # Connect to the SQLite database
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    # Query the 'books' table based on the search term
    cursor.execute('''SELECT DISTINCT title, author, genre, status 
                      FROM books 
                      WHERE title LIKE ? OR author LIKE ? OR genre LIKE ?''', 
                   ('%' + search_term + '%', '%' + search_term + '%', '%' + search_term + '%'))
    results = cursor.fetchall()

    # Close connection
    conn.close()

    # Update the results listbox with search results
    results_listbox.delete(0, tk.END)
    for result in results:
        results_listbox.insert(tk.END, result[0])

# Function to borrow a book
def borrow_book(title, user):
    # Connect to the SQLite database
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    # Update the book's status to 'Borrowed'
    cursor.execute('''UPDATE books SET status = 'Borrowed' WHERE title = ?''', (title,))
    # Add book to 'borrowed_books' table with the due date set 14 days from now
    cursor.execute('''INSERT INTO borrowed_books (user, title, due_date) VALUES (?, ?, DATE('now', '+14 days'))''', (user, title))

    # Commit changes and close connection
    conn.commit()
    conn.close()

# Function to return a book
def return_book(title):
    # Connect to the SQLite database
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    # Update the book's status to 'Available'
    cursor.execute('''UPDATE books SET status = 'Available' WHERE title = ?''', (title,))
    # Remove the book from 'borrowed_books' table
    cursor.execute('''DELETE FROM borrowed_books WHERE title = ?''', (title,))

    # Commit changes and close connection
    conn.commit()
    conn.close()

# Function to borrow selected book with additional checks
def borrow_selected_book(title):
    # Connect to the SQLite database
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    # Check if the book is already borrowed by the user
    cursor.execute('''SELECT * FROM borrowed_books WHERE user = ? AND title = ?''', (username, title))
    if cursor.fetchone():
        messagebox.showerror("Error", "You cannot borrow the same book twice!")
        return

    # If not already borrowed, proceed with borrowing
    borrow_book(title, username)
    messagebox.showinfo("Success", f"You have borrowed {title}")

    # Close connection
    conn.close()

# Function to return selected book with additional checks
def return_selected_book(title):
    # If no book is selected, show an error
    if not title:
        messagebox.showerror("Error", "No book selected to return!")
        return

    # Call the return_book function to return the book
    return_book(title)
    messagebox.showinfo("Success", f"You have returned {title}")

# ---- GUI FUNCTIONS ----

# Main menu window
def main_menu():
    window = tk.Tk()
    window.title("A Hobbit's Library Manager")

    # Define fonts for labels and buttons
    label_font = ("Arial", 16)
    btn_font = ("Arial", 12)

    # Load and resize the "A_Hobbit_Library_Manager.png" image
    original_image = Image.open("A_Hobbit_Library_Manager.png")
    resized_image = original_image.resize((300, 300))  # Adjust the size as necessary
    library_image = ImageTk.PhotoImage(resized_image)
    image_references.append(library_image)  # Store reference to avoid garbage collection
    tk.Label(window, image=library_image).pack(pady=20)

    # Display welcome message and main menu buttons
    tk.Label(window, text=f"Welcome, {username}!", font=label_font).pack(pady=10)
    tk.Button(window, text="Search Books", command=search_window, font=btn_font).pack(pady=10)
    tk.Button(window, text="Borrowed Books", command=borrowed_books_window, font=btn_font).pack(pady=10)
    tk.Button(window, text="Exit", command=window.quit, font=btn_font).pack(pady=10)

    window.mainloop()

# Search books window
def search_window():
    search_win = tk.Toplevel()
    search_win.title("Search and Borrow Books")

    # Define fonts for labels and buttons
    label_font = ("Arial", 16)
    input_font = ("Arial", 12)

    # Load and display the "Search_Empty" image
    original_search_image = Image.open("Search_Empty.png")
    resized_search_image = original_search_image.resize((300, 200))  # Adjust the size as necessary
    search_image = ImageTk.PhotoImage(resized_search_image)
    image_references.append(search_image)  # Ensure the image isn't garbage collected
    tk.Label(search_win, image=search_image).pack(pady=10)

    # Display search bar, search button, results listbox, and other buttons
    global search_entry
    search_entry = tk.Entry(search_win, width=20, font=input_font)
    search_entry.pack(pady=10)
    tk.Button(search_win, text="Search", command=search_books, font=input_font).pack(pady=10)

    global results_listbox
    results_listbox = Listbox(search_win, width=30, font=input_font)
    results_listbox.pack(pady=10)

    tk.Button(search_win, text="Borrow Selected Book", command=lambda: borrow_selected_book(results_listbox.get(results_listbox.curselection())), font=input_font).pack(pady=10)
    tk.Button(search_win, text="Go back", command=search_win.destroy, font=input_font).pack(pady=10)

# Borrowed books window
def borrowed_books_window():
    borrowed_win = tk.Toplevel()
    borrowed_win.title("Borrowed Books")

    # Display list of borrowed books
    borrowed_books_list = Listbox(borrowed_win, width=30, font=("Arial", 12))
    borrowed_books_list.pack(pady=20)

    # Connect to the SQLite database to fetch borrowed books
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()
    try:
        cursor.execute('''SELECT title FROM borrowed_books WHERE user = ?''', (username,))
        borrowed_books = cursor.fetchall()
        for book in borrowed_books:
            borrowed_books_list.insert(tk.END, book[0])
    except sqlite3.Error as e:
        messagebox.showerror("Database Error", f"An error occurred: {str(e)}")

    conn.close()

    # Display return book and go back buttons
    tk.Button(borrowed_win, text="Return Book", command=lambda: return_selected_book(borrowed_books_list.get(borrowed_books_list.curselection())), font=("Arial", 12)).pack(pady=10)
    tk.Button(borrowed_win, text="Go back", command=borrowed_win.destroy, font=("Arial", 12)).pack(pady=10)

# Prompt user for their username
def get_username():
  user = simpledialog.askstring("Username", "Enter your username:", parent=None)
  # Ensure username is not empty
  while not user or user.strip() == '':
      messagebox.showerror("Error", "Username cannot be empty!")
      user = simpledialog.askstring("Username", "Enter your username:", parent=None)
  return user
username = get_username()

# Initialize the SQLite database by creating necessary tables
create_database()

# Populate the database with sample books
populate_database()

# Start the main window of the application
main_menu()
